<?php
/**
 * footer.php
 * The template for displaying the footer
 */
?>

    </main><!-- #main .site-main - CLOSE THE MAIN CONTENT AREA -->

<?php get_template_part('template-parts/footer/site-footer'); ?>

</div><!-- #page .site - CLOSE THE SITE WRAPPER -->

<?php wp_footer(); ?>
</body>
</html>